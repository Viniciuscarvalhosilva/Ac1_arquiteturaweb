package com.example.arquitetutawebac1.Controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import com.example.arquitetutawebac1.Models.Tbl_categorias;
import com.example.arquitetutawebac1.Repositories.Tbl_categoriaRepository;
import com.example.arquitetutawebac1.Repositories.Tbl_produtoRepository;

@RestController
@RequestMapping("/api/categoria")
public class Tbl_categoriaController {
    
    
    @Autowired
    private Tbl_categoriaRepository tbl_categoriaRepository;

    @GetMapping()
    public List<Tbl_categorias>getTbl_categorias() {
        return tbl_categoriaRepository.obterTodos();
    }
    @PostMapping()
    @ResponseStatus(HttpStatus.CREATED)
    public void postTbl_categorias(@RequestBody Tbl_categorias tbl_categorias) {
        tbl_categoriaRepository.salvar(tbl_categorias);
    }
    
    
    
}
