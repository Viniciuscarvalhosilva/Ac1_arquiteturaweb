package com.example.arquitetutawebac1;
import java.util.List;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Arquitetutawebac1Application {

	public static void main(String[] args) {
		SpringApplication.run(Arquitetutawebac1Application.class, args);
	}

}
