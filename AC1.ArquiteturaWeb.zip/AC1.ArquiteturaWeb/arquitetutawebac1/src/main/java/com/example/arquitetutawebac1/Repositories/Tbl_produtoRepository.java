package com.example.arquitetutawebac1.Repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.arquitetutawebac1.Models.Tbl_produto;


@Repository
public class Tbl_produtoRepository {
     
    @Autowired
    private EntityManager entityManager;



    
    
@Transactional
    public Tbl_produto salvar(Tbl_produto tbl_produto){
        tbl_produto = entityManager.merge(tbl_produto);
        return tbl_produto;
    }
    public List<Tbl_produto> obterTodos() {
        return entityManager.createQuery("from Tbl_produto", Tbl_produto.class).getResultList();
    }
    
    public List<Tbl_produto> obterPorId(int id){
        String jpql = " select c from Tbl_produto c where c.id like :id";
        TypedQuery<Tbl_produto> query = entityManager.createQuery(jpql, Tbl_produto.class);
        query.setParameter("id", "%" + id + "%");
        return query.getResultList();
    }
@Transactional
    public void excluir(Tbl_produto tbl_produto){
        entityManager.remove(tbl_produto);
    }
@Transactional
    public void excluir(int id){
        excluir(entityManager.find(Tbl_produto.class, id));
    }


    
}

    
