package com.example.arquitetutawebac1.Repositories;

import org.springframework.stereotype.Repository;

import com.example.arquitetutawebac1.Models.Tbl_categorias;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;



@Repository
public class Tbl_categoriaRepository {
    @Autowired
    private EntityManager entityManager;

     @Transactional
    public Tbl_categorias salvar (Tbl_categorias tbl_categorias){
        tbl_categorias = entityManager.merge(tbl_categorias);
        return tbl_categorias;

    }
    public List<Tbl_categorias> obterTodos() {
        return entityManager.createQuery("from Tbl_categorias", Tbl_categorias.class).getResultList();
    }

        @Transactional
    public void excluir(Tbl_categorias tbl_categorias){
        entityManager.remove(tbl_categorias);
    }
        @Transactional
    public void excluir(int id){
        excluir(entityManager.find(Tbl_categorias.class, id));
    }

    public List<Tbl_categorias> obterPorId(int id){
        String jpql = " select c from Tbl_categorias c where c.id like :id";
        TypedQuery<Tbl_categorias> query = entityManager.createQuery(jpql, Tbl_categorias.class);
        query.setParameter("id", "%" + id + "%");
        return query.getResultList();
    }



    
}
