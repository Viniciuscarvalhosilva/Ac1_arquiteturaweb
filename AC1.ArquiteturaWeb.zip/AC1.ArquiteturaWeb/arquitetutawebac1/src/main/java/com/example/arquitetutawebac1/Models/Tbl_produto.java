package com.example.arquitetutawebac1.Models;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity

public class Tbl_produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id_produto;
    @Column(length = 200, nullable = false)
    private String prod_nome;
    @Column(nullable = false)
    private int prod_qtd;
    //private int id_categoria;
    
    @ManyToOne
    @JoinColumn(name = "id_categoria")
    private Tbl_categorias tbl_categoria;
    
    public Tbl_produto(int id_produto, String prod_nome, int prod_qtd, int id_categoria) {
        this.id_produto = id_produto;
        this.prod_nome = prod_nome;
        this.prod_qtd = prod_qtd;
        //this.id_categoria = id_categoria;
    }


    public Tbl_produto() {
    }
    
    
    public int getId_produto() {
        return id_produto;
    }
    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }
    public String getProd_nome() {
        return prod_nome;
    }
    public void setProd_nome(String prod_nome) {
        this.prod_nome = prod_nome;
    }
    public int getProd_qtd() {
        return prod_qtd;
    }
    public void setProd_qtd(int prod_qtd) {
        this.prod_qtd = prod_qtd;
    }
    //public int getId_categoria() {
        //return id_categoria;
    //}
    //public void setId_categoria(int id_categoria) {
        //this.id_categoria = id_categoria;
   // }


   

    public Tbl_categorias getTbl_categoria() {
        return tbl_categoria;
    }


    public void setTbl_categoria(Tbl_categorias tbl_categoria) {
        this.tbl_categoria = tbl_categoria;
    }

    
}